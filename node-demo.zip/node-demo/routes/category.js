const express = require('express');
const fs = require('fs');
const db = require('./../db.json');

const categoryRouter = express.Router();

categoryRouter.get('/', (req, res) => {
    res.json(db["categories"]);
});

categoryRouter.post('/', (req, res) => {
    const categoryData = req.body;
    console.log(categoryData);
    db["categories"].push(categoryData);
    fs.writeFileSync(__dirname + '/../db.json', JSON.stringify(db));
    res.json({
        "message": "Category is saved",
        "category": categoryData
    });
});

module.exports = categoryRouter;